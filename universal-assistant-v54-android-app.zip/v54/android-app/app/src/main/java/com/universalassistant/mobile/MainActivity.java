package com.universalassistant.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.view.View;

public class MainActivity extends Activity {
  EditText url, token; TextView status; WebView web;
  @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
    url=findViewById(R.id.url); token=findViewById(R.id.token); status=findViewById(R.id.status); web=findViewById(R.id.web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE); web.setWebViewClient(new WebViewClient());
    findViewById(R.id.connect).setOnClickListener(v -> connect());
  }
  void connect(){String base=url.getText().toString().trim(); if(base.endsWith("/")) base=base.substring(0,base.length()-1); if(base.isEmpty()){status.setText("Enter system URL");return;}
    String t=token.getText().toString().trim(); status.setText("Connecting…"); web.setVisibility(View.VISIBLE); web.loadUrl(base+"/?pairToken="+android.net.Uri.encode(t)); status.setText("Connected interface opened. If pairing is required, complete it in the page."); }
}
